# Employee Query Engine — AI Engineering Internship Assignment (Ekam Apps)

## Developed by: Chandu B A  
Email: chandua.ba2001@gmail.com  
Role Applied: AI Engineering Intern at Ekam Apps

---

## Project Overview

This project is a Natural Language Query System for Employee Data.  
It allows users to query an employee database using plain English without knowing SQL or the database structure.

The system automatically:
- Discovers the database schema  
- Understands natural language questions  
- Generates and executes SQL queries dynamically  
- Supports both structured employee data and unstructured text search using embeddings  

It also includes a simple front-end for easy interaction.

---

## Tech Stack

| Component | Technology |
|------------|-------------|
| Backend | Python, Flask |
| Frontend | HTML, CSS, JavaScript |
| Database | SQLite |
| NLP | SentenceTransformers (`all-MiniLM-L6-v2`) |
| Search | FAISS (Semantic Search) |
| Others | Flask-CORS for API access |

---

### Project Structure

project/
│
├── backend/
│   ├── __init__.py
│   ├── db.py                     
│   ├── main.py                   
│   ├── run_query.py              
│   ├── mydb.sqlite               
│   ├── api/
│   │   ├── __init__.py
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   └── orm_models.py
│   │   ├── routes/
│   │   │   ├── __init__.py
│   │   │   ├── ingestion.py
│   │   │   ├── query.py          
│   │   │   ├── schema.py         
│   │   │   └── search.py         
│   │   └── services/
│   │       ├── __init__.py
│   │       ├── document_processor.py
│   │       ├── query_engine.py   
│   │       ├── schema_discovery.py
│   │       └── utils.py          
│   └── env/                      
│
├── frontend/
│   ├── public/
│   │   └── index.html            
│   ├── src/
│   │   ├── components/
│   │   │   ├── DatabaseConnector.js
│   │   │   ├── DocumentUploader.js
│   │   │   ├── QueryPanel.js
│   │   │   └── ResultsView.js
│   │   ├── App.js
│   │   ├── index.js
│   │   └── index.css
│   ├── package.json
│   └── package-lock.json
│
├── docker-compose.yml          
├── requirements.txt             
├── README.md
└── .gitignore                   


How to Run the Project

1. Clone the Repository
```bash
git clone https://github.com/Chandu-B-A/employee-nlp-query-engine.git
cd employee-query-engine/backend

2. Install Dependencies
pip install -r requirements.txt

3. Run the Flask Server
python main.py
Server runs on: http://127.0.0.1:5000

4. Open Frontend

Open frontend/public/index.html in your browser to use the app.

Contact
Email: chandua.ba2001@gmail.com
LinkedIn: https://www.linkedin.com/in/chandu-b-a-252272221
