from flask import Blueprint, request, jsonify
from api.services.document_processor import search_docs  # absolute import for clarity

# Use consistent naming and route prefix
query_bp = Blueprint("query_bp", __name__, url_prefix="/api/query")

@query_bp.route("/", methods=["GET"])
def handle_query():
    """
    Endpoint to handle natural language queries on documents or employee data.
    Example: /api/query?q=who manages finance
    """
    q = request.args.get("q", "").strip()
    
    if not q:
        return jsonify({"error": "Missing query"}), 400
    
    try:
        results = search_docs(q)
        return jsonify(results)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
