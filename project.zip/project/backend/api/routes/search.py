from flask import Blueprint, request, jsonify
from db import get_connection

search_bp = Blueprint("search_bp", __name__, url_prefix="/api/search")

@search_bp.route("/", methods=["GET"])
def search_employee():
    query = request.args.get("q", "").lower()
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM employees
        WHERE LOWER(name) LIKE ? OR LOWER(role) LIKE ? OR LOWER(department) LIKE ?
    """, (f"%{query}%", f"%{query}%", f"%{query}%"))

    rows = cursor.fetchall()
    conn.close()

    if not rows:
        return jsonify({"message": "No matching employee found."})

    employees = [dict(row) for row in rows]
    return jsonify(employees)

@search_bp.route("/all", methods=["GET"])
def get_all_employees():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM employees")
    rows = cursor.fetchall()
    conn.close()

    if not rows:
        return jsonify({"message": "No employees found in the database."})

    employees = [dict(row) for row in rows]
    return jsonify(employees)
