from flask import Blueprint, jsonify
from api.services.schema_discovery import discover_schema
from api.services.utils import fetch_table_data

schema_bp = Blueprint("schema_bp", __name__, url_prefix="/api/schema")

@schema_bp.route("/tables", methods=["GET"])
def get_tables():
    """
    Endpoint to get all tables and their columns.
    """
    schema = discover_schema()
    return jsonify(schema)

@schema_bp.route("/data/<table>", methods=["GET"])
def get_data(table):
    """
    Endpoint to fetch all rows from a specific table.
    """
    try:
        df = fetch_table_data(table)
        return jsonify(df.to_dict(orient="records"))
    except Exception as e:
        return jsonify({"error": str(e)}), 500
