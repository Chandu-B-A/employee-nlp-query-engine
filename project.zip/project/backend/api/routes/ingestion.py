from flask import Blueprint, request, jsonify

ingest_bp = Blueprint("ingest", __name__)

@ingest_bp.route("/ingest", methods=["POST"])
def ingest():
    data = request.json.get("text")
    if not data:
        return jsonify({"error": "No text provided"}), 400
    # Here you could add logic to update embeddings
    return jsonify({"message": "Document added successfully"})
