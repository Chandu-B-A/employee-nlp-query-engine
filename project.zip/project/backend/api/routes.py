# backend/api/routes.py
from flask import Blueprint, request, jsonify
from db import get_connection

api = Blueprint('api', __name__)

@api.route('/search', methods=['GET'])
def search_employee():
    query = request.args.get('q', '').lower()
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT * FROM employees
        WHERE LOWER(name) LIKE ? OR LOWER(role) LIKE ? OR LOWER(department) LIKE ?
    """, (f'%{query}%', f'%{query}%', f'%{query}%'))

    results = cursor.fetchall()
    conn.close()

    if not results:
        return jsonify({"message": "No matching employee found."})

    employees = [
        {key: row[key] for key in row.keys()}
        for row in results
    ]
    return jsonify(employees)
