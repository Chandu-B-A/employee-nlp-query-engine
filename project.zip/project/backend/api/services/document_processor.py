from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

# 🧠 Sample employee-related documents (you can later load from DB or text files)
docs = [
    "John Doe is a data analyst in the marketing department.",
    "Alice Johnson manages the finance team and handles budget planning.",
    "Robert is a senior software engineer specializing in artificial intelligence.",
    "Emma is an HR associate responsible for employee engagement and recruitment."
]

# 🔧 Load model and build FAISS index
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(docs, convert_to_numpy=True)

index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(embeddings)

def search_docs(query, top_k=3):
    """
    Performs semantic search on employee-related documents.

    Args:
        query (str): Natural language query.
        top_k (int): Number of results to return (default = 3).

    Returns:
        List[str]: Top matching document texts.
    """
    if not query.strip():
        return {"error": "Query cannot be empty."}

    try:
        q_emb = model.encode([query], convert_to_numpy=True)
        D, I = index.search(q_emb, top_k)

        # Convert FAISS results to readable text
        results = [docs[i] for i in I[0]]
        return {"query": query, "results": results}
    except Exception as e:
        return {"error": str(e)}
