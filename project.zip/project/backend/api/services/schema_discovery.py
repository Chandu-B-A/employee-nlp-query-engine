from api.services.utils import get_tables, get_columns

def discover_schema():
    """
    Dynamically discovers all tables and their columns from the connected database.
    Returns:
        dict: {table_name: [column1, column2, ...]}
    """
    schema = {}
    for table in get_tables():
        schema[table] = get_columns(table)
    return schema
