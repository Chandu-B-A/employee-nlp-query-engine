import os
import pandas as pd
from sqlalchemy import create_engine, inspect
from dotenv import load_dotenv

load_dotenv()

DB_URL = os.getenv("DATABASE_URL", "sqlite:///mydb.sqlite")

engine = create_engine(DB_URL)
inspector = inspect(engine)

def get_engine():
    return engine

def get_tables():
    return inspector.get_table_names()

def get_columns(table_name):
    return [col["name"] for col in inspector.get_columns(table_name)]

def fetch_table_data(table_name, limit=10):
    query = f"SELECT * FROM {table_name} LIMIT {limit}"
    return pd.read_sql(query, engine)
