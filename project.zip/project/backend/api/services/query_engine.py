import re
from api.services.utils import get_engine

def nlp_to_sql(query):
    query = query.lower()
    if "hr" in query:
        return "SELECT * FROM employees WHERE department='HR'"
    elif "salary" in query and "greater" in query:
        amount = re.findall(r'\d+', query)
        if amount:
            return f"SELECT * FROM employees WHERE salary > {amount[0]}"
    return "SELECT * FROM employees"

def execute_sql(query):
    engine = get_engine()
    return engine.execute(query)
