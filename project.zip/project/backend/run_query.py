import asyncio
from pathlib import Path
from api.services.document_processor import DocumentProcessor

async def main():
    # Folder with your documents
    doc_dir = Path("V:/flask/project/sample_docs")
    files = list(doc_dir.glob("*.txt"))  # all txt files

    # Initialize processor
    dp = DocumentProcessor(index_dir="V:/flask/project/veci")

    # Process documents (creates embeddings + saves metadata)
    await dp.process_documents([str(f) for f in files])
    print(f"Processed {len(files)} documents.")

    # Now run a query
    query = "What is the candidate's name?"
    results = dp.search(query, top_k=3)

    print("Query Results:")
    for r in results:
        print(r)

# Run async
asyncio.run(main())
