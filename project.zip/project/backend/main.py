from flask import Flask
from api.routes.query import query_bp
from api.routes.schema import schema_bp
from api.routes.ingestion import ingest_bp
from api.routes.search import search_bp
from flask_cors import CORS

def create_app():
    app = Flask(__name__)
    CORS(app)  # Allow frontend React requests

    app.register_blueprint(query_bp)
    app.register_blueprint(schema_bp)
    app.register_blueprint(ingest_bp)
    app.register_blueprint(search_bp)


    @app.route("/")
    def home():
        return {"message": "Employee Query Engine Backend Running"}

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
