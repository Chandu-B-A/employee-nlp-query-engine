import React, { useState } from "react";
import "./index.css";

function App() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [tableData, setTableData] = useState([]);

  const runQuery = async () => {
    const res = await fetch(`http://127.0.0.1:5000/query?q=${query}`);
    const data = await res.json();
    setResults(data);
  };

  const fetchTables = async () => {
    const res = await fetch(`http://127.0.0.1:5000/tables`);
    const data = await res.json();
    console.log(data);
  };

  const fetchSampleData = async (tableName) => {
    const res = await fetch(`http://127.0.0.1:5000/data/${tableName}`);
    const data = await res.json();
    setTableData(data);
  };

  return (
    <div className="App">
      <h1>Employee Query Engine</h1>
      <div className="query-box">
        <input
          type="text"
          value={query}
          placeholder="Ask about employees..."
          onChange={(e) => setQuery(e.target.value)}
        />
        <button onClick={runQuery}>Search</button>
      </div>

      <h2>Search Results</h2>
      <ul>
        {results.map((r, i) => (
          <li key={i}>{r}</li>
        ))}
      </ul>

      <h2>Sample Table Data (DB)</h2>
      <button onClick={() => fetchSampleData("employees")}>Load Employees</button>
      <table border="1">
        <thead>
          <tr>
            {tableData[0] &&
              Object.keys(tableData[0]).map((col, i) => <th key={i}>{col}</th>)}
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, i) => (
            <tr key={i}>
              {Object.values(row).map((val, j) => (
                <td key={j}>{val}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
