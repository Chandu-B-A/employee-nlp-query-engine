import React, {useState} from 'react';

export default function DatabaseConnector({onConnected}) {
  const [conn, setConn] = useState("");
  const [status, setStatus] = useState(null);

  const testConnect = async () => {
    setStatus("testing");
    const form = new FormData();
    form.append("connection_string", conn);
    const res = await fetch("/api/ingest/database", {method:"POST", body: form});
    const data = await res.json();
    if (res.ok) {
      setStatus("success");
      onConnected && onConnected(conn, data.schema);
    } else {
      setStatus("error: " + data.detail || JSON.stringify(data));
    }
  };

  return (
    <div>
      <h3>Connect Database</h3>
      <input value={conn} onChange={(e)=>setConn(e.target.value)} placeholder="postgresql+asyncpg://user:pass@localhost/db" style={{width:"70%"}}/>
      <button onClick={testConnect}>Connect & Analyze</button>
      <div>{status}</div>
    </div>
  );
}
