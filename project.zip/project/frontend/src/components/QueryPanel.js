import React, {useState} from 'react';

export default function QueryPanel({connectionString, onResult}) {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    setLoading(true);
    const payload = {connection_string: connectionString, query: q};
    const res = await fetch("/api/query", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    setLoading(false);
    onResult(data);
  };
  return (
    <div>
      <h3>Query</h3>
      <textarea value={q} onChange={(e)=>setQ(e.target.value)} rows={3} style={{width:"80%"}}/>
      <br/>
      <button onClick={submit} disabled={loading}>{loading ? "Running...":"Run Query"}</button>
    </div>
  );
}
