import React from 'react';

export default function ResultsView({data}) {
  if (!data) return null;
  if (data.error) return <div>Error: {data.error}</div>;
  if (data.results?.rows) {
    const rows = data.results.rows;
    if (!rows.length) return <div>No rows</div>;
    const keys = Object.keys(rows[0]);
    return (
      <div>
        <h4>Table Results</h4>
        <table border="1">
          <thead><tr>{keys.map(k=> <th key={k}>{k}</th>)}</tr></thead>
          <tbody>
            {rows.map((r, i) => <tr key={i}>{keys.map(k=> <td key={k}>{String(r[k])}</td>)}</tr>)}
          </tbody>
        </table>
      </div>
    );
  }
  if (data.results?.documents) {
    return (
      <div>
        <h4>Documents</h4>
        {data.results.documents.map((d,i)=>(
          <div key={i} style={{border:"1px solid #ccc",margin:6,padding:6}}>
            <div>source: {d.meta?.source}</div>
            <div>score: {d.score}</div>
          </div>
        ))}
      </div>
    );
  }
  return <pre>{JSON.stringify(data, null, 2)}</pre>;
}
