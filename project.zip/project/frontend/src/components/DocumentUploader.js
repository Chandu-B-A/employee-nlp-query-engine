import React, {useState} from 'react';

export default function DocumentUploader() {
  const [files, setFiles] = useState([]);
  const [job, setJob] = useState(null);

  const upload = async () => {
    const fd = new FormData();
    files.forEach(f => fd.append("files", f));
    const res = await fetch("/api/ingest/documents", {method:"POST", body: fd});
    const data = await res.json();
    setJob(data.job_id);
  };

  return (
    <div>
      <h3>Upload Documents</h3>
      <input type="file" multiple onChange={(e)=>setFiles([...e.target.files])} />
      <button onClick={upload}>Upload & Index</button>
      <div>Job: {job}</div>
    </div>
  );
}
